<?php echo e($slot); ?>

<?php /**PATH D:\Lomba\Lomba UINC\App\back-end\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>