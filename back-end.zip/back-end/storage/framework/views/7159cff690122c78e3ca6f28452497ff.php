<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Lomba\Lomba UINC\App\back-end\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>