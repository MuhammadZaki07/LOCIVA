<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class DataSource extends Model
{
    use HasUuids, SoftDeletes;
    protected $guarded = ['id'];

    public function syncLogs()
    {
        return $this->hasMany(DataSyncLog::class);
    }

    public function latestSyncLog()
    {
        return $this->hasOne(DataSyncLog::class)->latestOfMany('started_at');
    }
}
