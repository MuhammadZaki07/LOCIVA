<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class BusinessTypeWeight extends Model
{
    use HasUuids, SoftDeletes;
    protected $guarded = ['id'];

    public function businessType()
    {
        return $this->belongsTo(BusinessType::class);
    }
}
